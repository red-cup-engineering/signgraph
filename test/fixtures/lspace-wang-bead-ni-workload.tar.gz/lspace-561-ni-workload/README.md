# L-Space finite Wang/bead workload

This is actual exact byte content for the original 561 NI custody and SignGraph consumer inputs. There is one finite 2x2 Wang edge-matched tile layout, a derived bead loom carrier, a cellular sheaf input, and a FOUR Chu incidence pairing. It is intentionally **not** a replacement source implementation, an infinite Wang-tiling result, or an installed web service.

- Source API: https://github.com/red-cup-engineering/signgraph/blob/main/src/cellular-sheaf.mjs
- Original storage: https://github.com/red-cup-engineering/uri-services-section/tree/main/services/ni-services-section/services/immutable-content-custody-service
- Use the `rootNi` in manifest.json to call `readTree` once an authorized host retains these blobs.
- Each immutable blob lives at objects/immutable/sha-256/<two digest characters>/<full digest> with its exact canonical media sidecar; `manifest.json` is external index metadata for this fixture, not an asserted new identity scheme.
- The finite sheaf `cochain` has exactly matching seam restrictions; changing NW.east gold to sky introduces two distinct one-hot basis coordinates and Dirichlet energy 2 under identity edge-stalk metric. Units are categorical and this is not a physical-energy prediction.

The scope of this data is a reusable *specific consuming workload*, not a declaration that all Semioverse contexts form a single glued sheaf.

In the native Data-owned FOUR knowledge vocabulary, **potential** is positive-only, **active** is negative-only, **absurd** is unknown and **stable** is contested. The original archived positive=`active` representation is superseded by this corrected fixture; because the bytes changed, its ChU and enclosing tree NI both changed.
